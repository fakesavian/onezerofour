// Update timestamp
function updateTimestamp() {
    const now = new Date();
    const timeElement = document.querySelector('.time');
    const dateElement = document.querySelector('.date');
    
    timeElement.textContent = now.toTimeString().split(' ')[0];
    dateElement.textContent = now.toISOString().split('T')[0].replace(/-/g, '.');
}

setInterval(updateTimestamp, 1000);
updateTimestamp();

// Generate random data for metrics
function generateMetricData(length = 20) {
    return Array.from({ length }, () => Math.random() * 80 + 20);
}

// Draw metric graphs with value indicators
function drawMetricGraph(canvas, data, color) {
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    
    ctx.clearRect(0, 0, width, height);
    
    // Draw grid
    ctx.strokeStyle = 'rgba(0, 255, 0, 0.1)';
    ctx.lineWidth = 0.5;
    
    for (let i = 0; i < width; i += 20) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, height);
        ctx.stroke();
    }
    
    for (let i = 0; i < height; i += 20) {
        ctx.beginPath();
        ctx.moveTo(0, i);
        ctx.lineTo(width, i);
        ctx.stroke();
    }
    
    // Draw graph
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.beginPath();
    
    const step = width / (data.length - 1);
    data.forEach((value, index) => {
        const x = index * step;
        const y = height - (value / 100 * height);
        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });
    
    ctx.stroke();

    // Draw current value indicator
    const currentValue = data[data.length - 1].toFixed(1);
    ctx.fillStyle = color;
    ctx.font = '12px "Share Tech Mono"';
    ctx.textAlign = 'right';
    ctx.fillText(currentValue + '%', width - 5, 15);
}

// Enhanced wireframe display
function drawWireframe(canvas) {
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    
    ctx.clearRect(0, 0, width, height);
    
    // Draw grid
    ctx.strokeStyle = 'rgba(0, 255, 0, 0.1)';
    ctx.lineWidth = 0.5;
    
    for (let i = 0; i < width; i += 30) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, height);
        ctx.stroke();
    }
    
    for (let i = 0; i < height; i += 30) {
        ctx.beginPath();
        ctx.moveTo(0, i);
        ctx.lineTo(width, i);
        ctx.stroke();
    }
    
    // Draw rotating cube with technical annotations
    const time = Date.now() * 0.001;
    ctx.strokeStyle = '#00ffff';
    ctx.lineWidth = 2;
    
    ctx.save();
    ctx.translate(width/2, height/2);
    ctx.rotate(time * 0.5);
    
    const size = 120;
    const points = [
        [-size, -size, -size],
        [size, -size, -size],
        [size, size, -size],
        [-size, size, -size],
        [-size, -size, size],
        [size, -size, size],
        [size, size, size],
        [-size, size, size]
    ];
    
    const edges = [
        [0,1], [1,2], [2,3], [3,0],
        [4,5], [5,6], [6,7], [7,4],
        [0,4], [1,5], [2,6], [3,7]
    ];
    
    // Project 3D points to 2D with perspective
    const projected = points.map(point => {
        const [x, y, z] = point;
        const perspective = 1000;
        const scale = perspective / (perspective + z);
        return [x * scale, y * scale];
    });
    
    // Draw edges with glow effect
    ctx.shadowColor = '#00ffff';
    ctx.shadowBlur = 10;
    edges.forEach(([i, j]) => {
        ctx.beginPath();
        ctx.moveTo(projected[i][0], projected[i][1]);
        ctx.lineTo(projected[j][0], projected[j][1]);
        ctx.stroke();
    });
    
    // Draw technical annotations
    ctx.restore();
    
    // Add data readouts
    ctx.font = '12px "Share Tech Mono"';
    ctx.fillStyle = '#00ffff';
    ctx.textAlign = 'left';
    
    const readouts = [
        `ROTATION: ${(time * 28.6).toFixed(1)}°`,
        `VERTICES: 8`,
        `EDGES: 12`,
        `SCALE: ${size}px`
    ];
    
    readouts.forEach((text, i) => {
        ctx.fillText(text, 10, 20 + i * 20);
    });
}

// Initialize and update metrics
const metricCanvases = document.querySelectorAll('.metric-graph');
const metricData = Array.from(metricCanvases, () => generateMetricData());
const metricColors = ['#00ff00', '#00ffff', '#ff6b00'];

function updateMetrics() {
    metricCanvases.forEach((canvas, index) => {
        metricData[index].shift();
        metricData[index].push(Math.random() * 80 + 20);
        drawMetricGraph(canvas, metricData[index], metricColors[index]);
    });
}

// Initialize wireframe
const wireframeCanvas = document.getElementById('wireframeDisplay');

// Animation loop
function animate() {
    updateMetrics();
    drawWireframe(wireframeCanvas);
    requestAnimationFrame(animate);
}

animate();
